﻿namespace SGreene_Lab4_CPT206
{
    public class Lab4
    {
        //nsmes are nice and simple
        public string Name { get; set; }


        //now the popualtion
        public int Population { get; set; }


        //now the flags
        public string FlagDescription { get; set; }


        //Now the flower
        public string Flower { get; set; }


        //Here is the color
        public string Color { get; set; }


        //NOw th elargest citeies
        public string ThreeLargestCities { get; set; }



        //cannot forget the captail
        public string Capital { get; set; }


        //how much are they making
        public double Income { get; set; }


        //how many jobs
        public double ComputerJobsPercent { get; set; }

       
    }
}
