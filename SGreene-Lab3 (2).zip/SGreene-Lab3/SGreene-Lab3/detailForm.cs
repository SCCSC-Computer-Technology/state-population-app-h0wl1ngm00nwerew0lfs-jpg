﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//I think I dded it right?
using Lab4;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;

namespace SGreene_Lab3
{
    public partial class detailForm : Form
    {

        //the good old classic exit button
      
        //messed up and didnt want to change things to get ridf of the 1
        private void btnExit_Click_1(object sender, EventArgs e)
        {
            this.Close();

        }


        private string GetDatabaseColumnName(string userSelection)
        {
            //using a swtich since it seems handy this time
            //this should grab what the user entered in the text box to see it it matches here
            switch (userSelection)
            {
                case "State Names": 
                    
                    return "[StateNames]";

                case "Population":
                    
                    return "[StatePopulation]";


                case "Flag Description":
                    
                    return "[StateFlagDesc]";


                case "State Flower":

                    return "[StateFlower]";


                case "State Bird":

                    return "[StateBird]";


                case "State Colors":

                    return "[StateColors]";


                case "Largest City":

                    return "[LargestCities]";


                case "State Capital":

                    return "[StateCapital]";
                

                case "Median Income":

                    return "[MedianIncome]";
                

                case "Computer Related Jobs": 
                    
                    return "[PercentageOfJobs]";
                

                default: return "[StateNames]";
            }
        }


        //this sbuold bind the asve item button

        //cannot forget aboutt he calss libabry

        //The lab4 problem should be fixed by connecting to the class librabry
        Lab4 state = new Lab4
        {
            //the rows should match to the database in the project
            State_Name = row.StateNames,

            Population = row.StatePopulation,

            Flag_Description = row.StateFlagDescription,

            Flower = row.StateFlower,

            Bird = row.StateBird,

            Colors = row.StateColors,

            Largest_Cities = row.LargestCities,

            Capitol = row.StateCapitol,
            
            Median_Income = row.MedianIncome,

            Percentage_Tech_Jobs = row.PercentageOfJobs
        };



        private void statesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.statesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.unitedStates1DataSet);

        }




        // this should cause the progrma to acutally load everything
        private void Details_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'unitedStates1DataSet.States' table. You can move, or remove it, as needed.
            this.statesTableAdapter.Fill(this.unitedStates1DataSet.States);
            statesBindingSource.Filter = StateFilter;

            statesDataGridView.ColumnHeaderMouseClick += dataGridView1_ColumnHeaderMouseClick;
        }


        //this should sort in ascending ordeer when clicked

        private void btnSortAscending_Click_1(object sender, EventArgs e)
        {
            if (comboSortBy.SelectedItem != null)
            {
                string columnID = GetDatabaseColumnName(comboSortBy.SelectedItem.ToString());

                statesBindingSource.Sort = columnID + " ASC";
            }
        }




        //this should when click sort the info in descedning order

        private void btnSortDescending_Click_1(object sender, EventArgs e)
        {
            if (comboSortBy.SelectedItem != null)
            {
                string columnID = GetDatabaseColumnName(comboSortBy.SelectedItem.ToString());

                statesBindingSource.Sort = columnID + " DESC";
            }
        }



        //A reset button
        //hopefully it wont be needed or used much
        private void btnReset_Click_1(object sender, EventArgs e)
        {
            statesBindingSource.Sort = null;
            statesBindingSource.Filter = null;

            comboSortBy.SelectedIndex = -1;
            try
            {
                this.statesTableAdapter.Fill(this.unitedStates1DataSet.States);
            }
            catch
            {
                MessageBox.Show("Data is having issues. Please wait.");
            }
        }

        //this should wehn clicked show everything

        private void btnShowall_Click_1(object sender, EventArgs e)
        {

            statesBindingSource.Filter = null;
            statesBindingSource.Sort = null;

            try
            {
                this.statesTableAdapter.Fill(this.unitedStates1DataSet.States);
                statesBindingSource.MoveFirst();
            }


            //let the user know there is a problem
            catch
            {
                MessageBox.Show("Error. Please wait a moment. Trying to get data now.");
            }
        }
    }
}
